package main

import (
	"fmt"
)

type Node struct {
	value byte
	next  *Node
}
type Stack struct {
	top  *Node
	size int
}
type Queue struct {
	size int
	tail *Node
}

func (stack *Stack) push(element byte) {
	stack.top = &Node{
		value: element,
		next:  stack.top,
	}
	stack.size++
}
func (stack *Stack) pop() byte {
	value := stack.top.value
	stack.top = stack.top.next
	stack.size--
	return value
}

func (stack *Stack) isEmpty() bool {
	return stack.size == 0
}
func (stack *Stack) getTop() byte {
	return stack.top.value
}

func (stack *Stack) getSize() int {
	return stack.size
}

func (queue *Queue) isEmpty() bool {
	return queue.tail == nil
}

func (queue *Queue) enqueue(elem byte) {
	newNode := &Node{
		value: elem,
		next:  nil,
	}
	if queue.isEmpty() {
		queue.tail = newNode
		newNode.next = queue.tail
	} else {
		newNode.next = queue.tail.next
		queue.tail.next = newNode
		queue.tail = newNode
	}
	queue.size++
}
func (queue *Queue) dequeue() byte {
	if queue.isEmpty() {
		fmt.Printf("La cola esta vacia.\n")
	} else {
		value := queue.tail.next.value
		//fmt.Printf("El elemento desencolado es: %v\n", queue.tail.next.value)
		queue.tail.next = queue.tail.next.next
		queue.size--
		return value
	}
	return '1'
}

func isPalindrome(stack *Stack, queue *Queue, length int) bool {
	for i := 0; i < length; i++ {
		if stack.pop() != queue.dequeue() {
			return false
		}
	}
	return true
}
func (queue *Queue) peek() {
	auxNode := queue.tail.next
	for i := 0; i < queue.size; i++ {
		fmt.Printf("Elemento: %v \n", auxNode.value)
		auxNode = auxNode.next
	}
}
func (queue *Queue) length() int {
	return queue.size
}
func main() {
	var palabra string

	newQueue := &Queue{
		size: 0,
	}
	newStack := &Stack{
		size: 0,
	}
	fmt.Printf("Ingrese una palabra: ")
	fmt.Scan(&palabra)
	for i := 0; i < len(palabra); i++ {
		newQueue.enqueue(palabra[i])
		newStack.push(palabra[i])
	}
	fmt.Printf("%v", isPalindrome(newStack, newQueue, len(palabra)))
}
