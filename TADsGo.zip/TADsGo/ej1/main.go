package main

import (
	"fmt"
	"main/TADs"
)

func main() {
	fmt.Println("Hello, Modules!")
	TADs.PrintHello()

}
