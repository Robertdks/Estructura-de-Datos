package TADs

import "fmt"

type Node struct {
	value int
	next  *Node
}
type Stack struct {
	top  *Node
	size int
}

func PrintHello() {
	fmt.Println("Hello, Modules! This is mypackage speaking!")
}

func (stack *Stack) push(element int) {
	stack.top = &Node{
		value: element,
		next:  stack.top,
	}
	stack.size++
}
func (stack *Stack) pop() int {
	value := stack.top.value
	stack.top = stack.top.next
	stack.size--
	return value
}

func (stack *Stack) isEmpty() bool {
	return stack.size == 0
}
func (stack *Stack) getTop() int {
	return stack.top.value
}

func (stack *Stack) getSize() int {
	return stack.size
}
