package main

import "fmt"

type Node struct {
	value    int
	nextNode *Node
}

type Queue struct {
	size int
	tail *Node
}

func (queue *Queue) isEmpty() bool {
	return queue.tail == nil
}

func (queue *Queue) enqueue(elem int) {
	newNode := &Node{
		value:    elem,
		nextNode: nil,
	}
	if queue.isEmpty() {
		queue.tail = newNode
		newNode.nextNode = queue.tail
	} else {
		newNode.nextNode = queue.tail.nextNode
		queue.tail.nextNode = newNode
		queue.tail = newNode
	}
	queue.size++
}
func (queue *Queue) dequeue() {
	if queue.isEmpty() {
		fmt.Printf("La cola esta vacia.\n")
	} else {
		fmt.Printf("El elemento desencolado es: %v\n", queue.tail.nextNode.value)
		queue.tail.nextNode = queue.tail.nextNode.nextNode
		queue.size--
	}
}

func (queue *Queue) peek() {
	auxNode := queue.tail.nextNode
	for i := 0; i < queue.size; i++ {
		fmt.Printf("Elemento: %v ", auxNode.value)
		fmt.Printf("posicion: %v %v", i+1, "\n")
		auxNode = auxNode.nextNode
	}
}
func (queue *Queue) length() int {
	return queue.size
}
func main() {
	newQueue := &Queue{
		size: 0,
	}
	var elem [5]int

	for i := 0; i < 5; i++ {
		elem[i] = i + 1
	}

	for i := 0; i < 5; i++ {
		//fmt.Printf("Ingrese el elemento: ")
		//fmt.Scan(&elem)
		newQueue.enqueue(elem[i])
	}
	newQueue.dequeue()
	newQueue.peek()
	fmt.Printf("El tamaño de la cola es: %v", newQueue.length())
}
