package main

import "fmt"

type Node struct {
	value int
	next  *Node
}
type Stack struct {
	top  *Node
	size int
}

func (stack *Stack) push(element int) {
	stack.top = &Node{
		value: element,
		next:  stack.top,
	}
	stack.size++
}
func (stack *Stack) pop() int {
	value := stack.top.value
	stack.top = stack.top.next
	stack.size--
	return value
}

func (stack *Stack) isEmpty() bool {
	return stack.size == 0
}
func (stack *Stack) getTop() int {
	return stack.top.value
}

func (stack *Stack) getSize() int {
	return stack.size
}

type Queue struct {
	size int
	tail *Node
}

func (queue *Queue) isEmpty() bool {
	return queue.tail == nil
}

func (queue *Queue) enqueue(elem int) {
	newNode := &Node{
		value: elem,
		next:  nil,
	}
	if queue.isEmpty() {
		queue.tail = newNode
		newNode.next = queue.tail
	} else {
		newNode.next = queue.tail.next
		queue.tail.next = newNode
		queue.tail = newNode
	}
	queue.size++
}
func (queue *Queue) dequeue() {
	if queue.isEmpty() {
		fmt.Printf("La cola esta vacia.\n")
	} else {
		//fmt.Printf("El elemento desencolado es: %v\n", queue.tail.next.value)
		queue.tail.next = queue.tail.next.next
		queue.size--

	}
}

func (queue *Queue) peek() {
	auxNode := queue.tail.next
	for i := 0; i < queue.size; i++ {
		fmt.Printf("Elemento: %v \n", auxNode.value)
		auxNode = auxNode.next
	}
}
func (queue *Queue) length() int {
	return queue.size
}

func printInReverse(stack *Stack) {
	for i := 0; i < 10; i++ {
		fmt.Printf("%v \n", stack.pop())
	}
}
func main() {
	var numero [10]int
	for i := 0; i < 10; i++ {
		numero[i] = i + 1
	}
	newStack := &Stack{
		size: 0,
	}
	newQueue := &Queue{
		size: 0,
	}
	for i := 0; i < 10; i++ {
		//fmt.Printf("Ingrese el numero: ")
		//fmt.Scan(&numero)
		newStack.push(numero[i])
		newQueue.enqueue(numero[i])
	}
	fmt.Printf("Numeros de manera inversa:\n")
	printInReverse(newStack)

	fmt.Printf("Numeros en orden de ingreso\n")
	newQueue.peek()
}
