package main

type Date struct {
	year  int
	month int
	day   int
}

func main() {

}
