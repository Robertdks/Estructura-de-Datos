package main

import "fmt"

type Node struct {
	value  int
	before *Node
	next   *Node
}

type DLQueue struct {
	tail *Node
	size int
}

func (queue *DLQueue) enqueue(elem int) {
	newNode := &Node{
		value:  elem,
		before: nil,
		next:   nil,
	}
	if queue.isEmpty() {
		queue.tail = newNode
		queue.tail.before = newNode //Defino el primer nodo con ambos punteros apuntandose a si mismo
		queue.tail.next = newNode

	} else {
		newNode.next = queue.tail.next      // | new | ---> |head|
		newNode.before = queue.tail         // |tail| <--- | new |
		queue.tail.next = newNode           // |tail| ---> | new |
		queue.tail = newNode                // |tail| ahora es | new | ===> |new tail|
		queue.tail.next.before = queue.tail //|new tail| <--- |head|
	}
	queue.size++
}
func (queue *DLQueue) peek() {
	auxNode := queue.tail.next
	for i := 0; i < queue.size; i++ {
		fmt.Printf("\nElemento: %v \n", auxNode.value)
		fmt.Printf("Anterior: %v \n", auxNode.before.value)
		fmt.Printf("Siguiente %v \n", auxNode.next.value)
		auxNode = auxNode.next
	}
}
func (queue *DLQueue) dequeue() int {
	value := queue.tail.next.value
	if queue.getSize() == 1 {
		queue.tail.before = nil
		queue.tail.next = nil
		queue.tail = nil
	} else {
		queue.tail.next = queue.tail.next.next // |tail| ---> |second| ===> |second| ahora es |new head|
		queue.tail.next.before = queue.tail    // |tail| <--- |new head|
	}
	queue.size--
	return value
}
func (queue *DLQueue) getSize() int {
	return queue.size
}
func (queue *DLQueue) isEmpty() bool {
	return queue.size == 0
}

func main() {
	newQueue := &DLQueue{
		size: 0,
	}
	for i := 1; i <= 10; i++ {
		//fmt.Printf("Ingrese el numero: ")
		//fmt.Scan(&numero)
		newQueue.enqueue(i)
	}

	newQueue.peek()
	fmt.Printf("valor desencolado: %v \n", newQueue.dequeue())
	fmt.Printf("nueva cola: \n")
	newQueue.peek()
}
