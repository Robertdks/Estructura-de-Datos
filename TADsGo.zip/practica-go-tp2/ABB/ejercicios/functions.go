package ejercicios

import (
	"fmt"
	"strings"
	"unicode"
)

// Ejercicio 1
/*Cuenta regresiva: recibe un número entero e imprime todos los números comprendidos
entre el mismo y 0.*/

// Version iterativa
func CuentaRegresiva(numero int) {
	for i := numero; i > 0; i-- {
		fmt.Printf("decrementacion: %v \n", i)
	}
}

// Version recursiva

func CuentaRegresivaRecursiva(numero int) int {
	if numero == 1 {
		return numero
	}
	fmt.Println(numero)
	return CuentaRegresivaRecursiva(numero - 1)

}

// Ejercicio 2
/*Suma de enteros: permite sumar todos los números enteros comprendidos entre un
parámetro de inicio y uno de fin.*/

// Iterativa
func SumaEnteros(inicio int, fin int) int {
	var sum = 0
	if inicio > fin {
		var aux = inicio
		inicio = fin
		fin = aux
	}
	for i := inicio; i < fin; i++ {
		sum = sum + i
	}
	return sum
}

// Recursiva
func SumaEnterosRecursiva(inicio int, fin int, suma int) int {
	if inicio > fin {
		var aux = inicio
		inicio = fin
		fin = aux
	}
	suma += fin
	if inicio == fin {
		return suma
	}
	return SumaEnterosRecursiva(inicio, fin-1, suma)
}

// Ejercicio 3

// Iterativa
func FactorialEntero(numero int) int {
	factorial := 1
	for i := numero; i > 0; i-- {
		factorial = factorial * i
	}
	return factorial
}

// Recursiva
func FactorialEnteroRecursiva(numero int, factorial int) int {
	if numero == 1 {
		return factorial
	}
	factorial = factorial * numero
	return FactorialEnteroRecursiva(numero-1, factorial)
}

// Ejercicio 4

// Iterativa
func VocalesYConsonantes(palabra string) (int, int) {
	long := len(palabra)
	vocales := "aeiou"
	cantVocal := 0
	//fmt.Println(long)
	cantConso := long - 1
	for i := 0; i < long; i++ {
		for j := 0; j < 5; j++ {
			if palabra[i] == vocales[j] {
				cantVocal++
			}
		}
	}
	cantConso = cantConso - cantVocal
	return cantVocal, cantConso
}

// Recursiva
func VocYConRecursiva(palabra string, vocales int, consonantes int) (int, int) {
	if len(palabra) == 0 {
		return vocales, consonantes
	}
	palabra = strings.ToLower(palabra)
	switch palabra[0] {
	case 'a', 'e', 'i', 'o', 'u':
		return VocYConRecursiva(palabra[1:], vocales+1, consonantes)
	case ' ':
		return VocYConRecursiva(palabra[1:], vocales, consonantes)
	default:
		return VocYConRecursiva(palabra[1:], vocales, consonantes+1)
	}
}

// Ejercicio 5

// Iterativa
func BuscarMayuscula(cadena string) int {
	for i := 0; i < len(cadena); i++ {
		caracter := cadena[i]
		if unicode.IsUpper(rune(caracter)) {
			return i
		}
	}
	return -1
}

// Recursiva
func BuscarPosMayusRecursiva(cadena string, posicion int) int {
	if len(cadena) == 0 {
		return -1
	} else {
		caracter := cadena[0]
		if unicode.IsUpper(rune(caracter)) {
			return posicion
		}
	}
	return BuscarPosMayusRecursiva(cadena[1:], posicion+1)
}

// Ejercicio 6

// Iterativa

func MayorElemento(numeros []int) int {
	mayor := numeros[0]
	for i := 1; i < len(numeros); i++ {
		if numeros[i] > mayor {
			mayor = numeros[i]
		}
	}
	return mayor
}

// Recursiva

func MayorElementoRecursiva(numeros []int, mayor int) int {
	if len(numeros) == 0 {
		return mayor
	}
	if numeros[0] > mayor {
		return MayorElementoRecursiva(numeros[1:], numeros[0])
	}
	return MayorElementoRecursiva(numeros[1:], mayor)
}

//Ejercicio 7

// Iterativa

func InvertirArreglo(arreglo []int, invertido []int) {
	j := 0
	for i := len(arreglo) - 1; i >= 0; i-- {
		invertido[j] = arreglo[i]
		j++
	}
}

// Recursiva

func InvertirArregloRecursiva(arreglo []int, invertido []int, i int) []int {
	if len(arreglo) == 0 {
		return invertido
	}
	invertido[len(arreglo)-1] = arreglo[i]
	return InvertirArregloRecursiva(arreglo[1:], invertido[:], i)
}
