package main

import (
	"fmt"
	"math"
)

func buscarMaximo() {
	maximo := math.MinInt64
	var num int

	for i := 0; i < 5; i++ {
		fmt.Println("ingrese el numero:", (i + 1))
		fmt.Scan(&num)
		if num > maximo {
			maximo = num
		}
	}
	fmt.Printf("El mayor es: %v", maximo)
}

func main() {

	buscarMaximo()
	/*
			var resultado, factorial int

			ejercicios.CuentaRegresiva(numero1)
			resultado = ejercicios.SumaEnteros(numero1, numero2)
			fmt.Println(resultado)
			factorial = ejercicios.FactorialEntero(numero1)
			fmt.Println(factorial)

		vocales, consonantes := ejercicios.VocalesYConsonantes("hooalase mundo")
		fmt.Println("Cantidad de vocales:", vocales)
		fmt.Println("Cantidad de consonantes", consonantes)*/
	//numero1 := 5
	//numero2 := 2
	//fmt.Println(ejercicios.CuentaRegresivaRecursiva(numero1))

	//fmt.Println(ejercicios.SumaEnterosRecursiva(numero1, numero2, 0))
	//fmt.Println(ejercicios.FactorialEnteroRecursiva(numero1, 1))
	//fmt.Println(ejercicios.BuscarMayuscula("holaMundo"))
	//numeros := [5]int{3, -4, 5, 20, 0}
	//var aux [5]int
	//fmt.Println(ejercicios.MayorElemento(numeros[:]))
	//vocales, consonantes := ejercicios.VocYConRecursiva("hooalase mundo", 0, 0)
	//fmt.Println("Cantidad de vocales:", vocales)
	//fmt.Println("Cantidad de consonantes", consonantes)

	//fmt.Println(ejercicios.BuscarPosMayusRecursiva("aloA mundo", 0))
	//fmt.Println(ejercicios.MayorElementoRecursiva(numeros[1:], numeros[0]))
	//ejercicios.InvertirArreglo(numeros[:], invertido[:])
	//invertido := ejercicios.InvertirArregloRecursiva(numeros[:], aux[:], 0)
	/*for i := 0; i < len(invertido); i++ {
		fmt.Println(invertido[i])
	}*/
}
